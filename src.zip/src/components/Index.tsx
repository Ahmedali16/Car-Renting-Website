import React from 'react';
import { Box } from '@chakra-ui/react';

function Index() {
  return (
    <></>
  );
}



export default Index