
import Banner from './components/Banner/Banner';
import Guide from './components/Guide/Guide';
// import Guide from './components/Guide/Guide';
import Index from './components/Index'
import NavBar from './components/NavBar/NavBar'
import Working from './components/Working/Working';
function App() {
  return (
    <div className="App">
 
     <Index/>
     <NavBar/>
     <Banner/>
  <Working/>
 <Guide/>
    </div>
  );
}

export default App;
